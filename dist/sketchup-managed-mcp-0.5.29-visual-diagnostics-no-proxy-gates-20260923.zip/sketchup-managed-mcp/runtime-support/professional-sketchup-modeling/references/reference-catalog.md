# Reference catalog

The runtime reference set is loaded on demand. Links below are documentation routes, not permission to bypass the managed transaction or evidence checks.

- [RELEASE.md](../RELEASE.md): package version, supported hosts and install scope.

- [ATTRIBUTION.md](ATTRIBUTION.md)
- [ancient-gates.md](ancient-gates.md)
- [chinese-ancient-architecture-rules.md](chinese-ancient-architecture-rules.md)
- [chinese-tower-image-modeling.md](chinese-tower-image-modeling.md)
- [modeling-method-playbook.md](modeling-method-playbook.md)
- [image-to-su-staged-template.md](image-to-su-staged-template.md)
- [targeted-ancient-curved-study.md](targeted-ancient-curved-study.md)
- [chinese-ancient-regression-findings.md](chinese-ancient-regression-findings.md)
- [ancient-detail-decomposition.md](ancient-detail-decomposition.md)
- [yellow-crane-tower-lessons.md](yellow-crane-tower-lessons.md)
- [commercial-street-lessons.md](commercial-street-lessons.md)
- [change-focused-review.md](change-focused-review.md)
- [geometry-guard.md](geometry-guard.md)
- [HOST-ENABLEMENT.md](HOST-ENABLEMENT.md)
- [instance-layout-contract.md](instance-layout-contract.md)
- [managed-quality-review.md](managed-quality-review.md)
- [managed-recovery.md](managed-recovery.md)
- [managed-ruby-api.md](managed-ruby-api.md)
- [minimal-managed-example.md](minimal-managed-example.md)
- [parameter-dependency-contract.md](parameter-dependency-contract.md)
- [projection-brief-guide.md](projection-brief-guide.md)
- [progressive-image-reconstruction.md](progressive-image-reconstruction.md)
- [quality-check-contract.md](quality-check-contract.md)
- [read-only-corpus-reader.md](read-only-corpus-reader.md)
- [ref-pack-guide.md](ref-pack-guide.md)
- [ruby-snippets.md](ruby-snippets.md)
- [SOURCE-DIAGNOSIS.md](SOURCE-DIAGNOSIS.md)
- [trace-manifest-schema.md](trace-manifest-schema.md)
- [weak-model-starter.md](weak-model-starter.md)

- [shared-architectural-foundation](shared-architectural-foundation.md)
- [expert-operation](expert-operation.md)
- [guided-operation](guided-operation.md)
- [scoped-operations](scoped-operations.md)
- [source-reading-diagnostics](source-reading-diagnostics.md)
- [form-feature-review](form-feature-review.md)
- [assembly-review](assembly-review.md)
- [camera-capture-review](camera-capture-review.md)
- [independent-review](independent-review.md)
- [materials-editability-review](materials-editability-review.md)

- [source-dimensions.md](source-dimensions.md)：一次绑定的明确尺寸与实际对象读回。
- [reference-comparison.md](reference-comparison.md)：全图、局部映射和可选只读复核资料。
